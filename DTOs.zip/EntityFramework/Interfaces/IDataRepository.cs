﻿using EntityFramework.Models;
using DTOs;

namespace EntityFramework.Interfaces
{
    public interface IDataRepository
    {
        Task<int?> AddUser(User user);
        Task<int?> GetUserIdByCredentials(string email, string password);
        Task<List<WebUserDTO>?> GetAllUsers();
        Task<int?> AddMessage(Message message);
        Task<List<WebMessageDTO>?> GetMessagesByUserId(int UserId);
        
    }
}
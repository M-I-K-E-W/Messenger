using DTOs;
using EntityFramework.Interfaces;
using EntityFramework.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    //[Authorize]
    [AllowAnonymous]
    [ApiController]
    [Route("api")]
    public class MessageCenterController : ControllerBase
    {
        private readonly ILogger<MessageCenterController> _logger;
        private readonly IDataRepository _dataRepository;

        public MessageCenterController(
            ILogger<MessageCenterController> logger,
            IDataRepository dataRepository)
        {
            _logger = logger;
            _dataRepository = dataRepository;
        }

        #region Messages

        [Route("getMessages")]
        [EnableCors]
        [HttpPost]
        public async Task<IEnumerable<WebMessageDTO>?> GetMessages([FromForm]int recipientId)
        {

            return await _dataRepository.GetMessagesByUserId(recipientId);
        }

        [Route("getRecipients")]
        [EnableCors]
        [HttpPost]
        public async Task<IEnumerable<WebUserDTO>?> GetRecipients([FromForm]int userId)
        {
            return await _dataRepository.GetAllUsers();
        }

        #endregion Messages

        #region Users

        [Route("getUserIdByCredentials")]
        [EnableCors]
        [HttpPost]
        public async Task<int?> GetUserIdByCredentials([FromForm]string email, [FromForm]string password)
        {
            return await _dataRepository.GetUserIdByCredentials(email, password);
        }

        #endregion Users

    }
}
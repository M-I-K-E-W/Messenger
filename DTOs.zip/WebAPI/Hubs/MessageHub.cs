﻿using EntityFramework;
using EntityFramework.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using WebAPI.Controllers;
using DTOs;
using Microsoft.AspNetCore.Cors;

namespace WebAPI.Hubs
{
    public class MessageHub : Hub
    {

        private readonly ILogger<MessageHub> _logger;
        private readonly IDataRepository _dataRepository;

        private MessageHub(
            ILogger<MessageHub> logger,
            IDataRepository dataRepository)
        {
            _logger = logger;
            _dataRepository = dataRepository;
        }

        public override Task OnConnectedAsync()
        {
            // Add logging here
            return base.OnConnectedAsync();
        }

        public override Task OnDisconnectedAsync(Exception? exception)
        {
            // Add logging here
            return base.OnDisconnectedAsync(exception);
        }

        //[Authorize]
        [AllowAnonymous]
        [EnableCors]
        public async Task NewMessage(WebMessageDTO webMessage)
        {
            var messageId = await _dataRepository
                .AddMessage(
                    new EntityFramework.Models.Message { 
                        SenderUserId= webMessage.SenderUserId,
                        RecipientUserId= webMessage.RecipientUserId,
                        MessageBody = webMessage.MessageBody ?? String.Empty,
                        TimeStamp = DateTime.Now
                    }
                );

            await Clients.Others.SendAsync("NewMessage", webMessage);
        }

    }
}

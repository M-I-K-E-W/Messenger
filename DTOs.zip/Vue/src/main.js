import { createApp } from 'vue';
import App from './App.vue';

import router from './router'
import callHub from './signalr';
import store from './store';

createApp(App)
    .use(callHub)
    .use(router)
    .use(store)
    .mount('#app')

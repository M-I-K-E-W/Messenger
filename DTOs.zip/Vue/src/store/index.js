import { createStore } from 'vuex';

export default createStore({
    state: {
        user: []
    },
    mutations: {
        setCurrentUser(state, user) {
            state.user = user;
        },
    },
});

//in Methods, we can now use
//this.$store.commit('setCurrentUser', 'email', 'id');
﻿namespace DTOs
{
    public class WebMessageDTO
    {
        public DateTime TimeStamp { get; set; }
        public int SenderUserId { get; set; }
        public string? SenderEmail { get; set; }
        public int RecipientUserId { get; set; }
        public string? RecipientEmail { get; set; }
        public string? MessageBody { get; set; }
    }
}
